cara run 
npm run build 
npm run serve 
http://localhost:8080/#/

harusnya sudah semua kak sudah memperbaiki feedback assignment satu kemarin dimana nanti ketika habis login ada log out 
dan ketika setiap login dan menambahkan notes langsung balik ke beranda 
fitur sebelum nya harusnya ada 
dan ada fitur notif dan fitur install sudah bisa di akses saat offline 
